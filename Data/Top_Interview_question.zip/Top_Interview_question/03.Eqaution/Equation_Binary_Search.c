// X = A*N + B*log(N) + C*N*N*N;
// Input: A B C X
// Output: N
// 1 <= A <= 100
// 1 <= B <= 100
// 0 <= C <= 100
// 1 <= X <= 10^15
#include<stdio.h>
#define MAX1 100000000000001
#define MAX2 100001
int T,Case;
int A,B,C;
long long X,ans;
int log(long long n)
{
    double d = n;
    int count = 0;
    while (d >= 2.71878)
    {
        d /= 2.71878;
        count++;
    }
    return count;
}
void solve(long long X){
    long long start=0,end=C?MAX2:MAX1;
    long long mid;
    while(start<=end){
        mid=(start+end)>>1;
        long long tmp=A*mid+B*log(mid)+C*mid*mid*mid;
        if(tmp==X){
            ans=mid;
            return;
        }
        else if(tmp>X){
            end=mid-1;
        }
        else{

            start=mid+1;
        }

    }
    }
int main()
{

    freopen("Equation_input.txt", "r", stdin);
    freopen("Equation_output.txt", "w", stdout);
    int T;
    scanf("%d", &T);
    for (int Case = 1; Case <= T; Case++)
    {
        scanf("%d%d%d%lld",&A,&B,&C,&X);
        solve(X);
        printf("%d %lld\n",Case,ans);
    }
    return 0;
}
